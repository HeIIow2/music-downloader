# tells what exists
__all__ = ["shared", "object_handeling", "phonetic_compares"]
