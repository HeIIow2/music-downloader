class Song:
    def __init__(self, path: str):
        pass
